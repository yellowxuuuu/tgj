Pack downloaded from Freesound
----------------------------------------

"music box sounds"

This Pack of sounds contains sounds by the following user:
 - baujahr66 ( https://freesound.org/people/baujahr66/ )

You can find this pack online at: https://freesound.org/people/baujahr66/packs/9736/


Pack description
----------------

music box tones, recorded by ZOOM H2, separated and normalized


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 157277__baujahr66__spieluhr6.wav.wav
    * url: https://freesound.org/s/157277/
    * license: Creative Commons 0
  * 157276__baujahr66__spieluhr8.wav.wav
    * url: https://freesound.org/s/157276/
    * license: Creative Commons 0
  * 157275__baujahr66__spieluhr7.wav.wav
    * url: https://freesound.org/s/157275/
    * license: Creative Commons 0
  * 157274__baujahr66__spieluhr5.wav.wav
    * url: https://freesound.org/s/157274/
    * license: Creative Commons 0
  * 157273__baujahr66__spieluhr9.wav.wav
    * url: https://freesound.org/s/157273/
    * license: Creative Commons 0
  * 157272__baujahr66__spieluhr3.wav.wav
    * url: https://freesound.org/s/157272/
    * license: Creative Commons 0
  * 157271__baujahr66__spieluhr4.wav.wav
    * url: https://freesound.org/s/157271/
    * license: Creative Commons 0
  * 157270__baujahr66__spieluhr17.wav.wav
    * url: https://freesound.org/s/157270/
    * license: Creative Commons 0
  * 157269__baujahr66__spieluhr2.wav.wav
    * url: https://freesound.org/s/157269/
    * license: Creative Commons 0
  * 157268__baujahr66__spieluhr13.wav.wav
    * url: https://freesound.org/s/157268/
    * license: Creative Commons 0
  * 157267__baujahr66__spieluhr14.wav.wav
    * url: https://freesound.org/s/157267/
    * license: Creative Commons 0
  * 157266__baujahr66__spieluhr15.wav.wav
    * url: https://freesound.org/s/157266/
    * license: Creative Commons 0
  * 157265__baujahr66__spieluhr16.wav.wav
    * url: https://freesound.org/s/157265/
    * license: Creative Commons 0
  * 157264__baujahr66__spieluhr1.wav.wav
    * url: https://freesound.org/s/157264/
    * license: Creative Commons 0
  * 157263__baujahr66__spieluhr10.wav.wav
    * url: https://freesound.org/s/157263/
    * license: Creative Commons 0
  * 157262__baujahr66__spieluhr11.wav.wav
    * url: https://freesound.org/s/157262/
    * license: Creative Commons 0
  * 157261__baujahr66__spieluhr12.wav.wav
    * url: https://freesound.org/s/157261/
    * license: Creative Commons 0


