Pack downloaded from Freesound
----------------------------------------

"VSCO 2 CE  - Percussion - Xylophone"

This Pack of sounds contains sounds by the following user:
 - sgossner ( https://freesound.org/people/sgossner/ )

You can find this pack online at: https://freesound.org/people/sgossner/packs/21065/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 374706__sgossner__xylophone-f6-xylo_medium_g6_ff_01_far.wav.wav
    * url: https://freesound.org/s/374706/
    * license: Creative Commons 0
  * 374705__sgossner__xylophone-f5-xylo_medium_g5_ff_01_far.wav.wav
    * url: https://freesound.org/s/374705/
    * license: Creative Commons 0
  * 374704__sgossner__xylophone-f4-xylo_medium_g4_ff_01_far.wav.wav
    * url: https://freesound.org/s/374704/
    * license: Creative Commons 0
  * 374703__sgossner__xylophone-f3-xylo_medium_g3_ff_01_far.wav.wav
    * url: https://freesound.org/s/374703/
    * license: Creative Commons 0
  * 374702__sgossner__xylophone-c7-xylo_medium_c7_ff_01_far.wav.wav
    * url: https://freesound.org/s/374702/
    * license: Creative Commons 0
  * 374701__sgossner__xylophone-c6-xylo_medium_c6_ff_01_far.wav.wav
    * url: https://freesound.org/s/374701/
    * license: Creative Commons 0
  * 374700__sgossner__xylophone-c5-xylo_medium_c5_ff_01_far.wav.wav
    * url: https://freesound.org/s/374700/
    * license: Creative Commons 0
  * 374699__sgossner__xylophone-c4-xylo_medium_c4_ff_01_far.wav.wav
    * url: https://freesound.org/s/374699/
    * license: Creative Commons 0


